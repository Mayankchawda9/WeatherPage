const apiKey = "2804bce2ec1ae3dbbce01f27223e7bdd";
const apiUrl = "https://api.openweathermap.org/data/2.5/weather?units=metric&q=";
const defaultCity = "New York"; // Default city

const searchBox = document.querySelector(".search input");
const searchButton = document.querySelector(".search button");
const weatherIcon = document.querySelector(".weather-icon");
const dayNightInfo = document.querySelector(".day-night-info");
const loading = document.querySelector(".loading");

// Function to update weather icon based on conditions
function updateWeatherIcon(main) {
    if (main === "Clouds") weatherIcon.src = "./clouds.png";
    else if (main === "Clear") weatherIcon.src = "./clear.png";
    else if (main === "Rain") weatherIcon.src = "./rain.png";
    else if (main === "Drizzle") weatherIcon.src = "./drizzle.png";
    else if (main === "Mist") weatherIcon.src = "./mist.png";
}

function updateDayNightInfo(cityName, sunrise, sunset) {
    const currentTime = new Date().getTime() / 1000; 
    if (currentTime >= sunrise && currentTime < sunset) {
        dayNightInfo.innerHTML = `It's currently day in ${cityName}`;
    } else {
        dayNightInfo.innerHTML = `It's currently night in ${cityName}`;
    }
}

async function checkWeather(city) {
    loading.style.display = "block"; 
    try {
        const response = await fetch(apiUrl + city + `&appid=${apiKey}`);
        if (!response.ok) throw new Error('City not found or network issue.');
        const data = await response.json();

        console.log(data);

        document.querySelector(".city").innerHTML = data.name;
        document.querySelector(".temp").innerHTML = Math.round(data.main.temp) + "ºc";
        document.querySelector(".humidity").innerHTML = data.main.humidity + "%";
        document.querySelector(".wind").innerHTML = data.wind.speed + "km/h";
        updateWeatherIcon(data.weather[0].main);
        updateDayNightInfo(data.name, data.sys.sunrise, data.sys.sunset);

        
        document.querySelector(".error").style.display = "none";
    } catch (error) {
        console.error(error);
        document.querySelector(".error").style.display = "block";
    }
    loading.style.display = "none"; 
}
document.getElementById('theme-toggle').addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
});


// Event listener for the search button
searchButton.addEventListener("click", () => {
    checkWeather(searchBox.value);
});

// Call checkWeather on page load with the default city
document.addEventListener("DOMContentLoaded", () => {
    checkWeather(defaultCity);
});
